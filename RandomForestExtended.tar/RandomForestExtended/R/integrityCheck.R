###############################################################################
### A function to test if the RandomForestExtended-package works as intended.
###############################################################################

integrityCheck <- function(){
  data("rf")
  data("phenotype")
  data("genotype")
  set.seed(1337)
  testrf1 <- randomForest(x=genotype, y=phenotype, ntree=100, mtry=50, nodesize=2, keep.inbag=T, keep.forest=T, importance=F, corr.bias=F, replace=T, nthreads=1)
  test1 <- identical(rf,testrf1)
  testrf2 <- randomForest(x=genotype, y=phenotype, ntree=100, mtry=50, nodesize=2, keep.inbag=T, keep.forest=T, importance=F, corr.bias=F, replace=T, nthreads=2)
  test2 <- ncol(testrf2$inbag)==100&ncol(testrf2$forest$nodepred)==100&ncol(testrf2$forest$oobpred)==100&ncol(testrf2$forest$oobmse)==100&ncol(testrf2$forest$oobmse)==100&ncol(testrf2$forest$mse)==100
  if(all(c(test1,test2))){return("integrity test was successful")}else{return("intergrity test was not successful")}
}